import numpy as np
import pandas as pd
import tensorflow as tf
import streamlit as st
import sklearn
import matplotlib.pyplot as plt

print("✅ All required libraries are successfully installed.")
print(f"TensorFlow version: {tf.__version__}")